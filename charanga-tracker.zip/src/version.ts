// Fuente de verdad única para la versión de la app.
// Actualizar aquí al hacer release — se usa en App.tsx y useEmitter.ts
export const APP_VERSION = "1.3.0";
