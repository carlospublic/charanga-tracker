export const BG_LOCATION_TASK = "CHARANGA_BG_LOCATION_TASK";
export const STORAGE_KEY_EVENT_ID = "charanga:emittingEventId";
export const STORAGE_KEY_LAST_SAVED = "charanga:lastSaved";
export const STORAGE_KEY_SESSION_ID = "charanga:emitSessionId";
export const STORAGE_KEY_SESSION_STARTED_AT = "charanga:sessionStartedAt";
